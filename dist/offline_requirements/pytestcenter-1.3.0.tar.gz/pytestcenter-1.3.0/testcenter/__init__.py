"""
@author yoram@ignissoft.com
"""

__version__ = '1.3.0'
