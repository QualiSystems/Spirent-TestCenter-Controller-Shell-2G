CloudShell shell core package powered by QualiSystems
