CloudShell Traffic Controller Shell base package, powered by Quali.

This base package provides base classes for CloudShell Traffic Controller driver and handler and helpers utilities.
