"""
@author yoram@ignissoft.com
"""

__version__ = '1.5.2'
